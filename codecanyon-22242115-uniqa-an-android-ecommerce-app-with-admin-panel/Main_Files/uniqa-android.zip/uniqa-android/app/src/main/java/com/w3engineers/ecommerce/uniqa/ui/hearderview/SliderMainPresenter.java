package com.w3engineers.ecommerce.uniqa.ui.hearderview;

import com.w3engineers.ecommerce.uniqa.data.helper.base.BasePresenter;

public class SliderMainPresenter extends BasePresenter<SliderMainMvpView> {
}
