package com.w3engineers.ecommerce.uniqa.ui.aboutus;

import com.w3engineers.ecommerce.uniqa.data.helper.base.MvpView;

public interface AboutUsMvpView extends MvpView {
}
