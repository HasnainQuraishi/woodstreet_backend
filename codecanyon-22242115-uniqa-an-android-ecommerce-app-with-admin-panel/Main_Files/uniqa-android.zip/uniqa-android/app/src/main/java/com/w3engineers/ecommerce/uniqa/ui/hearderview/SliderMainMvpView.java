package com.w3engineers.ecommerce.uniqa.ui.hearderview;

import com.w3engineers.ecommerce.uniqa.data.helper.base.MvpView;

public interface SliderMainMvpView extends MvpView {
}
