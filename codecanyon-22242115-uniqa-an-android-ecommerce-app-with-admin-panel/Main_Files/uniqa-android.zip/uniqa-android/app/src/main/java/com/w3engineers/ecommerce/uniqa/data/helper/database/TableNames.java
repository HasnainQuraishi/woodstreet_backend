package com.w3engineers.ecommerce.uniqa.data.helper.database;

public interface TableNames {
    String CODES = "CART";
}
