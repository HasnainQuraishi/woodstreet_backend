package com.w3engineers.ecommerce.uniqa.ui.onboarding;

import com.w3engineers.ecommerce.uniqa.data.helper.base.MvpView;

public interface OnBoardingMvpView extends MvpView {
}
