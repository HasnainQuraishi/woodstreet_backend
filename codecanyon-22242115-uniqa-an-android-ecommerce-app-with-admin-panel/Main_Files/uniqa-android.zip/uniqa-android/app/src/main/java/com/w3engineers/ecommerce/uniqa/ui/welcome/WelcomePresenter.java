package com.w3engineers.ecommerce.uniqa.ui.welcome;

import com.w3engineers.ecommerce.uniqa.data.helper.base.BasePresenter;

public class WelcomePresenter extends BasePresenter<WelcomeMvpView> {
}
