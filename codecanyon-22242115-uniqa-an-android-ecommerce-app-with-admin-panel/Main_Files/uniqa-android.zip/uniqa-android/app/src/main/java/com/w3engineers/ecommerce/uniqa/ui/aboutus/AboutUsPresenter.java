package com.w3engineers.ecommerce.uniqa.ui.aboutus;

import com.w3engineers.ecommerce.uniqa.data.helper.base.BasePresenter;

public class AboutUsPresenter extends BasePresenter<AboutUsMvpView> {
}
