package com.w3engineers.ecommerce.uniqa.ui.addcart;

import com.w3engineers.ecommerce.uniqa.data.helper.base.BasePresenter;

public class CartPresenter extends BasePresenter<CartMvpView> {
}
