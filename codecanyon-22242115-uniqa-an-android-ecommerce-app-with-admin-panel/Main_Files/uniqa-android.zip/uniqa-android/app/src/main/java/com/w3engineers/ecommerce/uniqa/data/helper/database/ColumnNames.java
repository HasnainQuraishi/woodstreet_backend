package com.w3engineers.ecommerce.uniqa.data.helper.database;

public interface ColumnNames {
    String ID = "id";
}
